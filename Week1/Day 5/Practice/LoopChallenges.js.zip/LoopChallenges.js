
//first
for(var i =1 ; i<21 ;i++){
    if (i%2== 1 ){
        console.log(i)
    }
}

//second
for (var i = 100; i>0;i--){
    if (i %3 ==0){
        console.log(i)
    }
}

//fourth
var sum = 0 
for (var i=0 ; i < 101;i++ ){
    sum=sum+i
}
console.log(sum)


//fifth
var sum=1
for (var i = 1 ; i < 13; i++){
    sum= sum*i
}
console.log(sum)