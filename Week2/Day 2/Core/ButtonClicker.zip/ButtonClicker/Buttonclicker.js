function hide(element){
   
   element.remove();
    console.log("element removed")
}

function setname(element){
element.innerText = "Logout";
}

