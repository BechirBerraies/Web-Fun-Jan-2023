console.log("page loaded...");

function startvid (element){
    document.getElementById("video").play()
    // console.log("video started")
    
}
function stopvid (element){
    document.getElementById("video").pause()
}