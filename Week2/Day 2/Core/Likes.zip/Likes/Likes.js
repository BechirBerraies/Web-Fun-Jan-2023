function increase(element){

    console.log("hi")
element.innerText ++ 
}
