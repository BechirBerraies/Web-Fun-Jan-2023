console.log("page loaded...");

function rename(element){
   
    document.getElementById(element).innerText = "John"
    }

function remove(element){
    document.getElementById(element).remove()
}

function increase(element){
    document.getElementById(element).innerText++
}

function decrease(element){
    document.getElementById(element).innerText--
}